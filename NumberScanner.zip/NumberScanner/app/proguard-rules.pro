# ML Kit and CameraX ship their own consumer rules.
-dontwarn com.google.mlkit.**
-keep class com.google.mlkit.** { *; }
