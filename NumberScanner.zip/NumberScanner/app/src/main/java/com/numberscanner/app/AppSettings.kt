package com.numberscanner.app

import android.content.Context

const val DEFAULT_ENDPOINT = "https://api.groq.com/openai/v1/chat/completions"
const val DEFAULT_MODEL = "qwen/qwen3.6-27b"

data class AppSettings(
    // Scanning
    val autoMode: Boolean = true,
    val stableFrames: Int = 1,          // 1 = accept as soon as a valid number is read
    val defaultZoom: Float = 1.5f,
    val keepScreenOn: Boolean = true,
    val handwritingMode: Boolean = false, // skip on-device OCR, read with AI

    // AI
    val aiEnabled: Boolean = true,      // AI fallback at all
    val autoAiInAutoMode: Boolean = true, // in auto mode, call AI by itself
    val aiDelaySec: Int = 3,            // how long on-device OCR tries before AI is called
    val aiOnlyWhenText: Boolean = true, // only call AI when some text is visible in the frame
    val endpoint: String = DEFAULT_ENDPOINT,
    val apiKey: String = "",
    val model: String = DEFAULT_MODEL,

    // Result
    val autoCopy: Boolean = true,
    val intlFormat: Boolean = false,    // copy as +8801XXXXXXXXX
    val vibrate: Boolean = true,
    val saveHistory: Boolean = true,
) {
    val hasApiKey: Boolean get() = apiKey.isNotBlank()
}

class SettingsRepo(context: Context) {
    private val p = context.getSharedPreferences("ns_settings", Context.MODE_PRIVATE)

    fun load(): AppSettings {
        val d = AppSettings()
        val ver = p.getInt("ver", 1)
        return AppSettings(
            autoMode = p.getBoolean("autoMode", d.autoMode),
            // v1.0 saved 2 here; from v1.1 the default is 1 (no re-checking once found)
            stableFrames = if (ver < 2) d.stableFrames else p.getInt("stableFrames", d.stableFrames),
            defaultZoom = p.getFloat("defaultZoom", d.defaultZoom),
            keepScreenOn = p.getBoolean("keepScreenOn", d.keepScreenOn),
            handwritingMode = p.getBoolean("handwritingMode", d.handwritingMode),
            aiEnabled = p.getBoolean("aiEnabled", d.aiEnabled),
            autoAiInAutoMode = p.getBoolean("autoAiInAutoMode", d.autoAiInAutoMode),
            aiDelaySec = p.getInt("aiDelaySec", d.aiDelaySec),
            aiOnlyWhenText = p.getBoolean("aiOnlyWhenText", d.aiOnlyWhenText),
            endpoint = p.getString("endpoint", d.endpoint) ?: d.endpoint,
            apiKey = p.getString("apiKey", d.apiKey) ?: d.apiKey,
            model = p.getString("model", d.model) ?: d.model,
            autoCopy = p.getBoolean("autoCopy", d.autoCopy),
            intlFormat = p.getBoolean("intlFormat", d.intlFormat),
            vibrate = p.getBoolean("vibrate", d.vibrate),
            saveHistory = p.getBoolean("saveHistory", d.saveHistory),
        )
    }

    fun save(s: AppSettings) {
        p.edit()
            .putInt("ver", 2)
            .putBoolean("autoMode", s.autoMode)
            .putInt("stableFrames", s.stableFrames)
            .putFloat("defaultZoom", s.defaultZoom)
            .putBoolean("keepScreenOn", s.keepScreenOn)
            .putBoolean("handwritingMode", s.handwritingMode)
            .putBoolean("aiEnabled", s.aiEnabled)
            .putBoolean("autoAiInAutoMode", s.autoAiInAutoMode)
            .putInt("aiDelaySec", s.aiDelaySec)
            .putBoolean("aiOnlyWhenText", s.aiOnlyWhenText)
            .putString("endpoint", s.endpoint)
            .putString("apiKey", s.apiKey)
            .putString("model", s.model)
            .putBoolean("autoCopy", s.autoCopy)
            .putBoolean("intlFormat", s.intlFormat)
            .putBoolean("vibrate", s.vibrate)
            .putBoolean("saveHistory", s.saveHistory)
            .apply()
    }
}
