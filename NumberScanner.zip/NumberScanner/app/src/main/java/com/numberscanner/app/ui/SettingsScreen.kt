package com.numberscanner.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.numberscanner.app.AppSettings
import com.numberscanner.app.DEFAULT_ENDPOINT
import com.numberscanner.app.DEFAULT_MODEL
import com.numberscanner.app.VisionApi
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(
    settings: AppSettings,
    onChange: (AppSettings) -> Unit,
    onBack: () -> Unit,
) {
    val s = settings
    val scope = rememberCoroutineScope()
    var showKey by remember { mutableStateOf(false) }
    var testing by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf<Pair<Boolean, String>?>(null) }
    val aiOn = s.aiEnabled

    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
    ) {
        ScreenHeader("সেটিংস", onBack)

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .imePadding()
                .navigationBarsPadding()
                .padding(bottom = 24.dp)
        ) {
            // ── Scanning ──
            SectionCard("স্ক্যান") {
                SettingSwitch(
                    "অটো মোড",
                    "নম্বর পেলেই নিজে থেকে স্ক্যান হবে, বোতাম চাপতে হবে না",
                    s.autoMode,
                ) { onChange(s.copy(autoMode = it)) }
                RowDivider()
                SettingSlider(
                    "নিশ্চিত হওয়ার ফ্রেম",
                    "১ = প্রথমবার পড়লেই গ্রহণ (দ্রুত)। ভুল নম্বর আসলে ২-৩ দিন",
                    "${s.stableFrames}",
                    s.stableFrames.toFloat(),
                    1f..5f,
                    steps = 3,
                ) { onChange(s.copy(stableFrames = it.roundToInt())) }
                RowDivider()
                SettingSlider(
                    "ডিফল্ট জুম",
                    "জুম দিলে ফোন একটু দূরে ধরা যায়, তাতে ফোকাস ভালো হয়",
                    "${"%.1f".format(s.defaultZoom)}x",
                    s.defaultZoom,
                    1f..3f,
                    steps = 3,
                ) { onChange(s.copy(defaultZoom = (it * 2).roundToInt() / 2f)) }
                RowDivider()
                SettingSwitch(
                    "✍️ হাতের লেখা মোড",
                    "ফোনের OCR বাদ দিয়ে সরাসরি AI পড়বে — হাতে লেখা নম্বরে অনেক নির্ভুল। API Key লাগবে। স্ক্যান স্ক্রিন থেকেও চালু/বন্ধ করা যায়",
                    s.handwritingMode,
                ) { onChange(s.copy(handwritingMode = it)) }
                RowDivider()
                SettingSwitch(
                    "স্ক্রিন জাগিয়ে রাখো",
                    "স্ক্যান করার সময় স্ক্রিন বন্ধ হবে না",
                    s.keepScreenOn,
                ) { onChange(s.copy(keepScreenOn = it)) }
            }

            // ── AI ──
            SectionCard("AI (অনলাইন)") {
                SettingSwitch(
                    "AI ব্যবহার করো",
                    "ফোনের OCR নম্বর না পেলে AI দিয়ে চেষ্টা করবে (হাতের লেখা, ঝাপসা ছবি)",
                    s.aiEnabled,
                ) { onChange(s.copy(aiEnabled = it)) }
                RowDivider()
                SettingSwitch(
                    "অটো মোডে AI নিজে থেকে কল",
                    "চালু থাকলে অটো মোডে কিছুক্ষণ নম্বর না পেলে AI নিজেই কল হবে। বন্ধ থাকলে শুধু বোতাম বা গ্যালারি থেকে AI চলবে",
                    s.autoAiInAutoMode,
                    enabled = aiOn,
                ) { onChange(s.copy(autoAiInAutoMode = it)) }
                RowDivider()
                SettingSlider(
                    "AI কলের আগে অপেক্ষা",
                    "এতক্ষণ ফোনের OCR চেষ্টা করবে, তারপর AI",
                    "${s.aiDelaySec} সে.",
                    s.aiDelaySec.toFloat(),
                    1f..10f,
                    steps = 8,
                    enabled = aiOn && s.autoAiInAutoMode,
                ) { onChange(s.copy(aiDelaySec = it.roundToInt())) }
                RowDivider()
                SettingSwitch(
                    "শুধু লেখা দেখা গেলে AI কল",
                    "ফ্রেমে কোনো লেখা না থাকলে AI কল হবে না — API খরচ বাঁচায়",
                    s.aiOnlyWhenText,
                    enabled = aiOn && s.autoAiInAutoMode,
                ) { onChange(s.copy(aiOnlyWhenText = it)) }
            }

            SectionCard("API কনফিগারেশন") {
                Column(
                    Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    ApiField(
                        label = "Endpoint URL",
                        value = s.endpoint,
                        placeholder = DEFAULT_ENDPOINT,
                        hint = "OpenAI-compatible (Groq, OpenAI, OpenRouter, Ollama…)",
                        keyboardType = KeyboardType.Uri,
                    ) { onChange(s.copy(endpoint = it.trim())) }

                    ApiField(
                        label = "API Key",
                        value = s.apiKey,
                        placeholder = "gsk_••••••••••••",
                        hint = "Groq: console.groq.com/keys",
                        keyboardType = KeyboardType.Password,
                        secret = !showKey,
                        trailing = {
                            IconButton(onClick = { showKey = !showKey }) {
                                Icon(
                                    if (showKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                    "দেখাও/লুকাও",
                                    tint = SubText,
                                )
                            }
                        },
                    ) { onChange(s.copy(apiKey = it.trim())) }

                    ApiField(
                        label = "Model",
                        value = s.model,
                        placeholder = DEFAULT_MODEL,
                        hint = "ছবি বুঝতে পারে এমন (vision) মডেল দিন",
                        keyboardType = KeyboardType.Text,
                    ) { onChange(s.copy(model = it.trim())) }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = {
                                testing = true
                                testResult = null
                                scope.launch {
                                    testResult = try {
                                        if (VisionApi.test(s)) true to "✅ কাজ করছে — মডেল নম্বর পড়তে পারছে"
                                        else false to "⚠️ API সাড়া দিয়েছে, কিন্তু নম্বর পড়তে পারেনি — vision মডেল কিনা দেখুন"
                                    } catch (e: Exception) {
                                        false to VisionApi.friendlyError(e)
                                    }
                                    testing = false
                                }
                            },
                            enabled = s.hasApiKey && !testing,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = OnAccent),
                        ) {
                            if (testing) {
                                CircularProgressIndicator(Modifier.size(18.dp), color = OnAccent, strokeWidth = 2.dp)
                                Spacer(Modifier.width(8.dp))
                            }
                            Text("কানেকশন টেস্ট", fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = {
                                onChange(s.copy(endpoint = DEFAULT_ENDPOINT, model = DEFAULT_MODEL))
                                testResult = null
                            },
                            shape = RoundedCornerShape(12.dp),
                        ) {
                            Text("ডিফল্ট", color = SubText)
                        }
                    }
                    testResult?.let { (ok, msg) ->
                        Text(msg, color = if (ok) Success else ErrorRed, fontSize = 13.sp)
                    }
                    if (!s.hasApiKey) {
                        Text(
                            "API Key না দিলেও অ্যাপ চলবে — শুধু ফোনের অফলাইন OCR ব্যবহার হবে।",
                            color = SubText,
                            fontSize = 12.sp,
                        )
                    }
                }
            }

            // ── Result ──
            SectionCard("ফলাফল") {
                SettingSwitch(
                    "প্রথম নম্বর অটো কপি",
                    "নম্বর পাওয়া মাত্র প্রথমটি ক্লিপবোর্ডে কপি হবে",
                    s.autoCopy,
                ) { onChange(s.copy(autoCopy = it)) }
                RowDivider()
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("কপির ফরম্যাট", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        Text(
                            if (s.intlFormat) "+8801712345678" else "01712345678",
                            color = SubText,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                        )
                    }
                    SegmentedChoice(listOf("01…", "+880…"), if (s.intlFormat) 1 else 0) {
                        onChange(s.copy(intlFormat = it == 1))
                    }
                }
                RowDivider()
                SettingSwitch(
                    "ভাইব্রেশন",
                    "নম্বর পেলে হালকা ভাইব্রেট করবে",
                    s.vibrate,
                ) { onChange(s.copy(vibrate = it)) }
                RowDivider()
                SettingSwitch(
                    "হিস্টোরি সেভ করো",
                    "স্ক্যান করা নম্বরগুলো ফোনেই সংরক্ষিত থাকবে",
                    s.saveHistory,
                ) { onChange(s.copy(saveHistory = it)) }
            }

            Spacer(Modifier.height(8.dp))
            Text(
                "Number Scanner v1.2 · ছবি কোথাও সেভ হয় না · API Key শুধু এই ফোনে থাকে",
                color = SubText.copy(alpha = 0.7f),
                fontSize = 11.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
            )
        }
    }
}

@Composable
private fun ApiField(
    label: String,
    value: String,
    placeholder: String,
    hint: String,
    keyboardType: KeyboardType,
    secret: Boolean = false,
    trailing: (@Composable () -> Unit)? = null,
    onValueChange: (String) -> Unit,
) {
    Column {
        Text(label, color = Color(0xFFBBC3D4), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text(placeholder, color = SubText.copy(alpha = 0.5f), fontSize = 13.sp) },
            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 14.sp, color = Color.White),
            visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType, autoCorrectEnabled = false),
            trailingIcon = trailing,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Accent,
                unfocusedBorderColor = Border,
                focusedContainerColor = Bg,
                unfocusedContainerColor = Bg,
                cursorColor = Accent,
            ),
        )
        Text(hint, color = SubText.copy(alpha = 0.8f), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
    }
}
