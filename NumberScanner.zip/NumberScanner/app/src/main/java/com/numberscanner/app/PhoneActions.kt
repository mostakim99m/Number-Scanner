package com.numberscanner.app

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.widget.Toast

object PhoneActions {

    fun formatted(n: String, intl: Boolean): String = if (intl) "+88$n" else n

    fun copy(context: Context, text: String) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("phone", text))
        // Android 13+ shows its own "copied" popup
        if (Build.VERSION.SDK_INT < 33) {
            Toast.makeText(context, "✅ $text কপি হয়েছে", Toast.LENGTH_SHORT).show()
        }
    }

    fun call(context: Context, n: String) =
        start(context, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$n")))

    fun sms(context: Context, n: String) =
        start(context, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$n")))

    fun whatsapp(context: Context, n: String) =
        start(context, Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/88$n")))

    private fun start(context: Context, intent: Intent) {
        try {
            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, "এই কাজের জন্য কোনো অ্যাপ পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
        }
    }
}
