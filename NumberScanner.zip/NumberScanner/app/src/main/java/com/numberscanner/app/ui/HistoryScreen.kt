package com.numberscanner.app.ui

import android.text.format.DateUtils
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.numberscanner.app.AppSettings
import com.numberscanner.app.HistoryRepo

@Composable
fun HistoryScreen(historyRepo: HistoryRepo, settings: AppSettings, onBack: () -> Unit) {
    var history by remember { mutableStateOf(historyRepo.load()) }
    var confirmClear by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
    ) {
        ScreenHeader("হিস্টোরি", onBack) {
            if (history.isNotEmpty()) {
                RoundIconButton(
                    Icons.Filled.DeleteSweep, "সব মুছুন",
                    background = Surface2, tint = ErrorRed,
                ) { confirmClear = true }
            }
        }

        if (history.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.History, null, tint = SubText, modifier = Modifier.size(56.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("এখনো কোনো নম্বর স্ক্যান হয়নি", color = SubText, fontSize = 15.sp)
                }
            }
        } else {
            LazyColumn(
                Modifier
                    .fillMaxSize()
                    .navigationBarsPadding(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                items(history, key = { it.number }) { item ->
                    val time = DateUtils.getRelativeTimeSpanString(
                        item.time, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS
                    ).toString()
                    val src = if (item.source == "AI") "🤖 AI" else "📱 অফলাইন"
                    NumberCard(item.number, settings.intlFormat, caption = "$time · $src")
                }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            containerColor = Surface1,
            title = { Text("সব হিস্টোরি মুছবেন?", color = Color.White, fontWeight = FontWeight.Bold) },
            text = { Text("${history.size}টি নম্বর মুছে যাবে। এটা আর ফেরত আনা যাবে না।", color = SubText) },
            confirmButton = {
                TextButton(onClick = {
                    historyRepo.clear()
                    history = emptyList()
                    confirmClear = false
                }) { Text("মুছুন", color = ErrorRed, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) { Text("বাতিল", color = SubText) }
            },
        )
    }
}
