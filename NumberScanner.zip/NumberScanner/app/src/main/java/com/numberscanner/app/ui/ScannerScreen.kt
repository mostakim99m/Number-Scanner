package com.numberscanner.app.ui

import android.graphics.Bitmap
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ZoomState
import androidx.camera.mlkit.vision.MlKitAnalyzer
import androidx.camera.view.CameraController
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Settings
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text as MlText
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.numberscanner.app.AppSettings
import com.numberscanner.app.HistoryRepo
import com.numberscanner.app.ImageUtils
import com.numberscanner.app.NumberExtractor
import com.numberscanner.app.PhoneActions
import com.numberscanner.app.VisionApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import android.graphics.Rect as ARect

/** How long a read number is "held" so the UI doesn't flicker between frames. */
private const val HOLD_MS = 2500L

private sealed interface Phase {
    data object Scanning : Phase
    data class Processing(val message: String) : Phase
    data class Result(val numbers: List<String>, val source: String, val copied: Boolean) : Phase
}

/** Per-scan bookkeeping that should not trigger recomposition. */
private class ScanTracker {
    var lastKey = ""
    var stableCount = 0
    var lastNumbers: List<String> = emptyList()
    var lastNumbersAt = 0L
    var textSeenSince = 0L
    var scanStart = System.currentTimeMillis()
    var aiBlockedUntil = 0L
    var busy = false

    // Zoom is re-applied every time the camera is re-bound (after a result)
    var zoomTarget = 1.5f
    var cameraOff = false
    var lastCrop: Bitmap? = null   // image the result came from (for AI re-read)
    var zoomPending = true

    fun reset() {
        lastKey = ""
        stableCount = 0
        lastNumbers = emptyList()
        lastNumbersAt = 0L
        textSeenSince = 0L
        scanStart = System.currentTimeMillis()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScannerScreen(
    settings: AppSettings,
    onSettingsChange: (AppSettings) -> Unit,
    historyRepo: HistoryRepo,
    onOpenSettings: () -> Unit,
    onOpenHistory: () -> Unit,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val view = LocalView.current
    val density = LocalDensity.current
    val currentSettings by rememberUpdatedState(settings)

    var phase by remember { mutableStateOf<Phase>(Phase.Scanning) }
    var statusText by remember { mutableStateOf("নম্বরের দিকে ক্যামেরা ধরুন") }
    var torchOn by remember { mutableStateOf(false) }
    var hasFlash by remember { mutableStateOf(false) }
    var zoomRatio by remember { mutableFloatStateOf(1f) }
    var maxZoom by remember { mutableFloatStateOf(1f) }
    var highlightBoxes by remember { mutableStateOf<List<ARect>>(emptyList()) }
    var frameRect by remember { mutableStateOf<ARect?>(null) }
    var numberInFrame by remember { mutableStateOf(false) }
    // Still image shown instead of the live camera while processing / showing a result
    var frozen by remember { mutableStateOf<Bitmap?>(null) }
    var frozenFit by remember { mutableStateOf(false) }
    var editIndex by remember { mutableStateOf<Int?>(null) }

    val tracker = remember { ScanTracker().apply { zoomTarget = settings.defaultZoom } }
    val recognizer = remember { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    val controller = remember { LifecycleCameraController(context) }
    val previewView = remember {
        PreviewView(context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
            )
            scaleType = PreviewView.ScaleType.FILL_CENTER
            // TextureView: makes previewView.bitmap reliable for the AI snapshot
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
    }

    // ── helpers ──────────────────────────────────────────────

    fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

    /** Part of a full preview snapshot inside the scan frame (plus a margin). */
    fun cropToFrame(bmp: Bitmap): Bitmap {
        val fr = frameRect ?: return bmp
        val padX = (fr.width() * 0.06f).toInt()
        val padY = (fr.height() * 0.35f).toInt()
        val l = (fr.left - padX).coerceIn(0, bmp.width - 1)
        val t = (fr.top - padY).coerceIn(0, bmp.height - 1)
        val r = (fr.right + padX).coerceIn(l + 1, bmp.width)
        val b = (fr.bottom + padY).coerceIn(t + 1, bmp.height)
        return Bitmap.createBitmap(bmp, l, t, r - l, b - t)
    }

    /** Show a still image and switch the camera OFF. */
    fun freeze(bmp: Bitmap?, fit: Boolean = false) {
        if (bmp != null) {
            frozen = bmp
            frozenFit = fit
        }
        torchOn = false
        tracker.cameraOff = true
        controller.unbind()
    }

    fun resumeScanning(aiCooldown: Boolean = false) {
        // Camera back ON; the still image stays until the live preview is streaming
        if (tracker.cameraOff) {
            tracker.cameraOff = false
            tracker.zoomPending = true
            controller.bindToLifecycle(lifecycleOwner)
            scope.launch {
                kotlinx.coroutines.delay(1500)
                if (phase is Phase.Scanning) frozen = null   // safety net
            }
        }
        tracker.lastCrop = null
        editIndex = null
        tracker.reset()
        if (aiCooldown) tracker.aiBlockedUntil = System.currentTimeMillis() + 10_000
        tracker.busy = false
        highlightBoxes = emptyList()
        numberInFrame = false
        statusText = "নম্বরের দিকে ক্যামেরা ধরুন"
        phase = Phase.Scanning
    }

    fun deliver(numbers: List<String>, source: String) {
        val s = currentSettings
        var copied = false
        if (s.autoCopy && numbers.isNotEmpty()) {
            PhoneActions.copy(context, PhoneActions.formatted(numbers[0], s.intlFormat))
            copied = true
        }
        if (s.vibrate) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        if (s.saveHistory) historyRepo.add(numbers, source)
        if (frozen == null) freeze(previewView.bitmap)
        if (tracker.lastCrop == null) tracker.lastCrop = frozen?.let { if (frozenFit) it else cropToFrame(it) }
        tracker.reset()
        tracker.busy = true
        highlightBoxes = emptyList()
        phase = Phase.Result(numbers, source, copied)
    }

    fun runAi(bitmap: Bitmap) {
        val s = currentSettings
        tracker.busy = true
        phase = Phase.Processing("🤖 AI দিয়ে খোঁজা হচ্ছে…")
        scope.launch {
            try {
                val nums = VisionApi.extractNumbers(bitmap, s)
                if (nums.isNotEmpty()) {
                    deliver(nums, "AI")
                } else {
                    toast("AI-ও কোনো নম্বর পায়নি")
                    resumeScanning(aiCooldown = true)
                }
            } catch (e: Exception) {
                toast(VisionApi.friendlyError(e))
                resumeScanning(aiCooldown = true)
            }
        }
    }

    /** OCR on a still bitmap (manual shot / gallery), then AI if allowed. */
    fun scanStill(bmp: Bitmap) {
        tracker.busy = true
        scope.launch {
            val text = try {
                recognizer.process(InputImage.fromBitmap(bmp, 0)).await().text
            } catch (e: Exception) {
                ""
            }
            val nums = NumberExtractor.extract(text)
            val s = currentSettings
            when {
                nums.isNotEmpty() -> deliver(nums, "ML Kit")
                s.aiEnabled && s.hasApiKey -> runAi(bmp)
                else -> {
                    toast(
                        if (!s.hasApiKey) "নম্বর পাওয়া যায়নি — AI-এর জন্য Settings-এ API Key দিন"
                        else "নম্বর পাওয়া যায়নি"
                    )
                    resumeScanning()
                }
            }
        }
    }

    /** Called for every analyzed camera frame (main thread). */
    fun onFrame(text: MlText?) {
        if (phase !is Phase.Scanning || tracker.busy) return
        val s = currentSettings
        val fr = frameRect
        val now = System.currentTimeMillis()

        val lines = text?.textBlocks?.flatMap { it.lines }.orEmpty()
        val inFrame = lines.filter { line ->
            val b = line.boundingBox ?: return@filter false
            fr == null || fr.contains(b.centerX(), b.centerY())
        }
        // ✍️ Handwriting mode: on-device OCR only tells us "there is text"; AI reads it
        if (s.handwritingMode && s.hasApiKey) {
            val hasText = inFrame.any { l -> l.text.any { it.isLetterOrDigit() } }
            highlightBoxes = emptyList()
            numberInFrame = false
            if (hasText) {
                if (tracker.textSeenSince == 0L) tracker.textSeenSince = now
            } else {
                tracker.textSeenSince = 0L
            }
            if (!s.autoMode) {
                statusText = if (hasText) "✍️ লেখা দেখা যাচ্ছে — বোতাম চাপুন" else "✍️ হাতের লেখা মোড — নম্বরে ধরুন"
                return
            }
            statusText = if (hasText) "✍️ স্থির রাখুন…" else "✍️ হাতের লেখা মোড — নম্বরে ধরুন"
            if (hasText && now - tracker.textSeenSince >= 1000L && now >= tracker.aiBlockedUntil) {
                val full = previewView.bitmap
                if (full != null) {
                    freeze(full)
                    val crop = cropToFrame(full)
                    tracker.lastCrop = crop
                    runAi(crop)
                }
            }
            return
        }

        val numbers = NumberExtractor.extract(inFrame.joinToString("\n") { it.text })

        // A number was read a moment ago: single frames that miss it are ignored,
        // so the status stays "found" instead of flickering back to "searching".
        if (numbers.isEmpty() && tracker.lastNumbers.isNotEmpty() && now - tracker.lastNumbersAt < HOLD_MS) {
            return
        }

        highlightBoxes = inFrame
            .filter { NumberExtractor.extract(it.text).isNotEmpty() }
            .mapNotNull { it.boundingBox }
        numberInFrame = numbers.isNotEmpty()

        if (numbers.isNotEmpty()) {
            val key = numbers.sorted().joinToString(",")
            if (key == tracker.lastKey && now - tracker.lastNumbersAt < HOLD_MS) {
                tracker.stableCount++
            } else {
                tracker.lastKey = key
                tracker.stableCount = 1
            }
            tracker.lastNumbers = numbers
            tracker.lastNumbersAt = now
            statusText = if (s.autoMode) "✅ নম্বর পাওয়া গেছে — স্থির রাখুন" else "✅ নম্বর পাওয়া গেছে — বোতাম চাপুন"
            if (s.autoMode && tracker.stableCount >= s.stableFrames) deliver(numbers, "ML Kit")
            return
        }

        tracker.lastNumbers = emptyList()
        val hasText = inFrame.any { l -> l.text.any { it.isLetterOrDigit() } }
        if (hasText) {
            if (tracker.textSeenSince == 0L) tracker.textSeenSince = now
        } else {
            tracker.textSeenSince = 0L
        }

        val aiArmed = s.autoMode && s.aiEnabled && s.autoAiInAutoMode && s.hasApiKey &&
            now >= tracker.aiBlockedUntil
        val since = if (s.aiOnlyWhenText) tracker.textSeenSince else tracker.scanStart

        statusText = when {
            aiArmed && since > 0L -> {
                val left = s.aiDelaySec - ((now - since) / 1000).toInt()
                if (left > 0) "🔍 লেখা দেখছি… ${left}s পর AI" else "🤖 AI চেক করছে…"
            }
            hasText -> "🔍 লেখা দেখছি, নম্বর খুঁজছি…"
            else -> "নম্বরের দিকে ক্যামেরা ধরুন"
        }

        if (aiArmed && since > 0L && now - since >= s.aiDelaySec * 1000L) {
            val full = previewView.bitmap
            if (full != null) {
                freeze(full)
                runAi(cropToFrame(full))
            }
        }
    }

    fun manualScan() {
        if (phase !is Phase.Scanning || tracker.busy) return
        val s = currentSettings
        val hand = s.handwritingMode && s.hasApiKey
        if (s.handwritingMode && !s.hasApiKey) toast("হাতের লেখা মোডের জন্য Settings-এ API Key দিন")
        val now = System.currentTimeMillis()
        if (!hand && tracker.lastNumbers.isNotEmpty() && now - tracker.lastNumbersAt < HOLD_MS) {
            deliver(tracker.lastNumbers, "ML Kit")
            return
        }
        val full = previewView.bitmap
        if (full == null) {
            toast("ছবি নেওয়া যায়নি, আবার চেষ্টা করুন")
            return
        }
        freeze(full)
        val crop = cropToFrame(full)
        tracker.lastCrop = crop
        if (hand) {
            runAi(crop)
        } else {
            phase = Phase.Processing("🔍 নম্বর খোঁজা হচ্ছে…")
            scanStill(crop)
        }
    }

    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri == null || phase !is Phase.Scanning) return@rememberLauncherForActivityResult
        tracker.busy = true
        phase = Phase.Processing("🖼️ ছবি থেকে নম্বর খোঁজা হচ্ছে…")
        scope.launch {
            val bmp = withContext(Dispatchers.IO) {
                runCatching { ImageUtils.loadBitmap(context, uri, 2000) }.getOrNull()
            }
            if (bmp == null) {
                toast("ছবিটি খোলা যায়নি")
                resumeScanning()
            } else {
                freeze(bmp, fit = true)
                tracker.lastCrop = bmp
                val s = currentSettings
                if (s.handwritingMode && s.hasApiKey) runAi(bmp) else scanStill(bmp)
            }
        }
    }

    // ── camera setup ─────────────────────────────────────────

    DisposableEffect(lifecycleOwner) {
        val main = ContextCompat.getMainExecutor(context)
        controller.cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
        controller.setEnabledUseCases(CameraController.IMAGE_ANALYSIS)
        controller.imageAnalysisBackpressureStrategy = ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST
        controller.isTapToFocusEnabled = true
        controller.isPinchToZoomEnabled = true
        controller.setImageAnalysisAnalyzer(
            main,
            MlKitAnalyzer(
                listOf(recognizer),
                ImageAnalysis.COORDINATE_SYSTEM_VIEW_REFERENCED,
                main,
            ) { result ->
                onFrame(result?.getValue(recognizer))
            }
        )
        previewView.controller = controller
        controller.bindToLifecycle(lifecycleOwner)

        val zoomObserver = Observer<ZoomState> { zs ->
            if (zs == null) return@Observer
            maxZoom = zs.maxZoomRatio
            zoomRatio = zs.zoomRatio
            if (tracker.zoomPending) {
                tracker.zoomPending = false
                hasFlash = controller.cameraInfo?.hasFlashUnit() == true
                controller.setZoomRatio(tracker.zoomTarget.coerceIn(zs.minZoomRatio, zs.maxZoomRatio))
            } else {
                tracker.zoomTarget = zs.zoomRatio   // remembers pinch-zoom too
            }
        }
        controller.zoomState.observe(lifecycleOwner, zoomObserver)

        // Drop the still image once the live preview is really back
        val streamObserver = Observer<PreviewView.StreamState> { st ->
            if (st == PreviewView.StreamState.STREAMING && phase is Phase.Scanning) frozen = null
        }
        previewView.previewStreamState.observe(lifecycleOwner, streamObserver)

        onDispose {
            previewView.previewStreamState.removeObserver(streamObserver)
            controller.zoomState.removeObserver(zoomObserver)
            controller.clearImageAnalysisAnalyzer()
            controller.unbind()
        }
    }

    DisposableEffect(settings.keepScreenOn) {
        view.keepScreenOn = settings.keepScreenOn
        onDispose { view.keepScreenOn = false }
    }

    // ── UI ───────────────────────────────────────────────────

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .onSizeChanged { size ->
                val w = size.width
                val h = size.height
                val fw = (w * 0.86f).toInt()
                val fh = with(density) { 150.dp.roundToPx() }
                val cx = w / 2
                val cy = (h * 0.42f).toInt()
                frameRect = ARect(cx - fw / 2, cy - fh / 2, cx + fw / 2, cy + fh / 2)
            }
    ) {
        AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())

        frozen?.let { bmp ->
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = null,
                contentScale = if (frozenFit) ContentScale.Fit else ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black),
            )
        }

        ScanOverlay(
            frame = frameRect,
            boxes = highlightBoxes,
            active = phase is Phase.Scanning && frozen == null,
            found = numberInFrame,
        )

        // Status chip above the frame, distance hint below
        frameRect?.takeIf { frozen == null }?.let { fr ->
            val topDp = with(density) { fr.top.toDp() }
            val bottomDp = with(density) { fr.bottom.toDp() }
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = (topDp - 50.dp).coerceAtLeast(0.dp))
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black.copy(alpha = 0.6f))
                    .border(1.dp, if (numberInFrame) Success.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.15f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(statusText, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            Text(
                "20–30 cm দূরে ধরুন · ট্যাপে ফোকাস · পিঞ্চে জুম",
                color = Color.White.copy(alpha = 0.55f),
                fontSize = 12.sp,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = bottomDp + 14.dp),
            )
        }

        // ── Top bar ──
        Row(
            Modifier
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.75f), Color.Transparent)))
                .statusBarsPadding()
                .padding(start = 18.dp, end = 12.dp, top = 8.dp, bottom = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("Number Scanner", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (settings.autoMode) "⚡ অটো মোড" else "✋ ম্যানুয়াল মোড",
                    color = if (settings.autoMode) Accent else SubText,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                )
            }
            ModeToggle(settings.autoMode) { auto ->
                tracker.reset()
                onSettingsChange(settings.copy(autoMode = auto))
            }
            Spacer(Modifier.width(8.dp))
            RoundIconButton(Icons.Filled.History, "হিস্টোরি", onClick = onOpenHistory)
            Spacer(Modifier.width(8.dp))
            RoundIconButton(Icons.Filled.Settings, "সেটিংস", badge = !settings.hasApiKey, onClick = onOpenSettings)
        }

        // ── Bottom controls ──
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))))
                .navigationBarsPadding()
                .padding(top = 40.dp, bottom = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ZoomChips(
                    options = listOf(1f, 1.5f, 2f, 3f).filter { it <= maxZoom + 0.01f },
                    current = zoomRatio,
                    onSelect = {
                        tracker.zoomTarget = it
                        controller.setZoomRatio(it)
                    },
                )
                Spacer(Modifier.width(10.dp))
                HandwritingChip(settings.handwritingMode) { on ->
                    if (on && !settings.hasApiKey) toast("হাতের লেখা মোডের জন্য Settings-এ API Key দিন")
                    tracker.reset()
                    onSettingsChange(settings.copy(handwritingMode = on))
                }
            }
            Spacer(Modifier.height(18.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 40.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RoundIconButton(Icons.Filled.PhotoLibrary, "গ্যালারি", size = 54.dp) {
                    galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                ShutterButton(auto = settings.autoMode, onClick = { manualScan() })
                RoundIconButton(
                    if (torchOn) Icons.Filled.FlashOn else Icons.Filled.FlashOff,
                    "ফ্ল্যাশ",
                    size = 54.dp,
                    enabled = hasFlash,
                    tint = if (torchOn) Accent else Color.White,
                ) {
                    torchOn = !torchOn
                    controller.enableTorch(torchOn)
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(
                if (settings.autoMode) "নম্বর পেলেই অটো স্ক্যান · বোতাম চাপলে এখনই স্ক্যান"
                else "নম্বরের দিকে ধরে বোতাম চাপুন",
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 12.sp,
            )
        }

        // ── Processing overlay ──
        val p = phase
        if (p is Phase.Processing) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.55f))
                    .clickable(enabled = true, onClick = {}),
                contentAlignment = Alignment.Center,
            ) {
                Column(
                    Modifier
                        .clip(RoundedCornerShape(22.dp))
                        .background(Surface1)
                        .border(1.dp, Accent.copy(alpha = 0.25f), RoundedCornerShape(22.dp))
                        .padding(horizontal = 36.dp, vertical = 28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    CircularProgressIndicator(color = Accent, strokeWidth = 3.dp, modifier = Modifier.size(42.dp))
                    Spacer(Modifier.height(16.dp))
                    Text(p.message, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }

    // ── Result sheet ──
    val p = phase
    if (p is Phase.Result) {
        editIndex?.let { idx ->
            EditNumberDialog(
                initial = p.numbers.getOrNull(idx) ?: "",
                onDismiss = { editIndex = null },
                onSave = { newNum ->
                    val old = p.numbers[idx]
                    val list = p.numbers.toMutableList().also { it[idx] = newNum }.distinct()
                    if (currentSettings.saveHistory) {
                        historyRepo.remove(old)
                        historyRepo.add(listOf(newNum), p.source)
                    }
                    if (idx == 0 && p.copied) {
                        PhoneActions.copy(context, PhoneActions.formatted(newNum, currentSettings.intlFormat))
                    }
                    phase = p.copy(numbers = list)
                    editIndex = null
                },
            )
        }
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { resumeScanning() },
            sheetState = sheetState,
            containerColor = Surface1,
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.CheckCircle, null, tint = Success, modifier = Modifier.size(26.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "${p.numbers.size}টি নম্বর পাওয়া গেছে",
                        color = Color.White,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f),
                    )
                    SourceBadge(p.source)
                }
                if (p.copied) {
                    Text(
                        "⚡ প্রথম নম্বরটি কপি হয়ে গেছে",
                        color = Accent,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(top = 6.dp, start = 36.dp),
                    )
                }
                Spacer(Modifier.height(10.dp))
                p.numbers.forEachIndexed { i, n ->
                    NumberCard(
                        n, settings.intlFormat,
                        highlight = i == 0 && p.copied,
                        onEdit = { editIndex = i },
                    )
                }
                val crop = tracker.lastCrop
                if (p.source != "AI" && settings.hasApiKey && crop != null) {
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(
                        onClick = {
                            p.numbers.forEach { historyRepo.remove(it) }
                            runAi(crop)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, Accent.copy(alpha = 0.5f)),
                    ) {
                        Text("🤖 নম্বর ভুল? AI দিয়ে আবার পড়ুন", color = Accent, fontWeight = FontWeight.SemiBold)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = { resumeScanning() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = OnAccent),
                ) {
                    Icon(Icons.Filled.CameraAlt, null)
                    Spacer(Modifier.width(8.dp))
                    Text("আবার স্ক্যান করুন", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun ModeToggle(auto: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color.Black.copy(alpha = 0.45f))
            .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(20.dp))
            .padding(3.dp)
    ) {
        listOf(true to "অটো", false to "ম্যানুয়াল").forEach { (value, label) ->
            val sel = value == auto
            Box(
                Modifier
                    .clip(RoundedCornerShape(17.dp))
                    .background(if (sel) Accent else Color.Transparent)
                    .clickable { if (!sel) onChange(value) }
                    .padding(horizontal = 12.dp, vertical = 7.dp)
            ) {
                Text(label, color = if (sel) OnAccent else Color.White.copy(alpha = 0.75f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun HandwritingChip(on: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .clip(RoundedCornerShape(22.dp))
            .background(if (on) Accent.copy(alpha = 0.22f) else Color.Black.copy(alpha = 0.5f))
            .border(1.dp, if (on) Accent else Color.White.copy(alpha = 0.18f), RoundedCornerShape(22.dp))
            .clickable { onChange(!on) }
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("✍️", fontSize = 14.sp)
        Spacer(Modifier.width(6.dp))
        Text(
            if (on) "হাতের লেখা" else "ছাপা",
            color = if (on) Accent else Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
        )
    }
}

@Composable
private fun EditNumberDialog(initial: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var value by remember { mutableStateOf(initial) }
    val digits = value.filter { it.isDigit() }
    val valid = Regex("^01[3-9]\\d{8}$").matches(digits)
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Surface1,
        title = { Text("নম্বর ঠিক করুন", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                OutlinedTextField(
                    value = value,
                    onValueChange = { v -> value = v.filter { it.isDigit() }.take(11) },
                    singleLine = true,
                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 22.sp, color = Color.White),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = if (valid) Accent else ErrorRed,
                        unfocusedBorderColor = Border,
                        cursorColor = Accent,
                    ),
                )
                Text(
                    if (valid) "✓ ঠিক আছে" else "০১৩–০১৯ দিয়ে শুরু ১১ ডিজিট দিন (${digits.length}/11)",
                    color = if (valid) Success else SubText,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(digits) }, enabled = valid) {
                Text("সেভ", color = if (valid) Accent else SubText, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("বাতিল", color = SubText) }
        },
    )
}

@Composable
private fun ZoomChips(options: List<Float>, current: Float, onSelect: (Float) -> Unit) {
    if (options.size < 2) return
    Row(
        Modifier
            .clip(RoundedCornerShape(22.dp))
            .background(Color.Black.copy(alpha = 0.5f))
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        options.forEach { z ->
            val sel = kotlin.math.abs(current - z) < 0.15f
            val label = if (z % 1f == 0f) "${z.toInt()}x" else "${z}x"
            Box(
                Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(if (sel) Accent.copy(alpha = 0.2f) else Color.Transparent)
                    .border(1.dp, if (sel) Accent else Color.Transparent, CircleShape)
                    .clickable { onSelect(z) },
                contentAlignment = Alignment.Center,
            ) {
                Text(label, color = if (sel) Accent else Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun ShutterButton(auto: Boolean, onClick: () -> Unit) {
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 0.85f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "pulseValue",
    )
    Box(
        Modifier
            .size(80.dp)
            .clip(CircleShape)
            .border(4.dp, if (auto) Accent else Color.White, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .size(if (auto) 62.dp * pulse else 62.dp)
                .clip(CircleShape)
                .background(if (auto) Accent.copy(alpha = 0.22f) else Color.White),
            contentAlignment = Alignment.Center,
        ) {
            if (auto) Icon(Icons.Filled.Bolt, "স্ক্যান", tint = Accent, modifier = Modifier.size(30.dp))
        }
    }
}

@Composable
private fun SourceBadge(source: String) {
    val ai = source == "AI"
    Box(
        Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (ai) Accent.copy(alpha = 0.15f) else Success.copy(alpha = 0.12f))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            if (ai) "🤖 AI" else "📱 অফলাইন",
            color = if (ai) Accent else Success,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
        )
    }
}

@Composable
private fun ScanOverlay(frame: ARect?, boxes: List<ARect>, active: Boolean, found: Boolean) {
    val progress by rememberInfiniteTransition(label = "scan").animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Reverse),
        label = "scanLine",
    )
    val accent = if (found) Success else Accent

    Canvas(Modifier.fillMaxSize()) {
        val f = frame ?: return@Canvas
        val l = f.left.toFloat()
        val t = f.top.toFloat()
        val r = f.right.toFloat()
        val b = f.bottom.toFloat()
        val radius = 18.dp.toPx()

        // Dim everything outside the frame
        val path = Path().apply {
            fillType = PathFillType.EvenOdd
            addRect(Rect(0f, 0f, size.width, size.height))
            addRoundRect(RoundRect(l, t, r, b, CornerRadius(radius)))
        }
        drawPath(path, Color.Black.copy(alpha = 0.55f))

        drawRoundRect(
            color = Color.White.copy(alpha = 0.22f),
            topLeft = Offset(l, t),
            size = Size(r - l, b - t),
            cornerRadius = CornerRadius(radius),
            style = Stroke(1.dp.toPx()),
        )

        // Corner brackets
        val c = 30.dp.toPx()
        val sw = 4.dp.toPx()
        listOf(
            Triple(l, t, Offset(1f, 1f)),
            Triple(r, t, Offset(-1f, 1f)),
            Triple(l, b, Offset(1f, -1f)),
            Triple(r, b, Offset(-1f, -1f)),
        ).forEach { (x, y, d) ->
            drawLine(accent, Offset(x, y), Offset(x + d.x * c, y), sw, StrokeCap.Round)
            drawLine(accent, Offset(x, y), Offset(x, y + d.y * c), sw, StrokeCap.Round)
        }

        // Moving scan line
        if (active) {
            val pad = 14.dp.toPx()
            val y = t + pad + (b - t - 2 * pad) * progress
            drawLine(
                brush = Brush.horizontalGradient(
                    listOf(Color.Transparent, accent, Color.Transparent),
                    startX = l,
                    endX = r,
                ),
                start = Offset(l + pad, y),
                end = Offset(r - pad, y),
                strokeWidth = 2.dp.toPx(),
            )
        }

        // Boxes around detected numbers
        boxes.forEach { bx ->
            drawRoundRect(
                color = Success,
                topLeft = Offset(bx.left - 6f, bx.top - 4f),
                size = Size(bx.width() + 12f, bx.height() + 8f),
                cornerRadius = CornerRadius(8.dp.toPx()),
                style = Stroke(2.dp.toPx()),
            )
        }
    }
}
