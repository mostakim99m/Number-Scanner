package com.numberscanner.app

import android.content.Context

data class HistoryItem(val number: String, val time: Long, val source: String)

class HistoryRepo(context: Context) {
    private val p = context.getSharedPreferences("ns_history", Context.MODE_PRIVATE)

    fun load(): List<HistoryItem> =
        (p.getString("items", "") ?: "")
            .lines()
            .mapNotNull { line ->
                val parts = line.split("|")
                if (parts.size < 3) null
                else HistoryItem(parts[0], parts[1].toLongOrNull() ?: 0L, parts[2])
            }

    fun add(numbers: List<String>, source: String) {
        val now = System.currentTimeMillis()
        val rest = load().filterNot { it.number in numbers }
        save((numbers.map { HistoryItem(it, now, source) } + rest).take(200))
    }

    fun remove(number: String) = save(load().filterNot { it.number == number })

    fun clear() {
        p.edit().remove("items").apply()
    }

    private fun save(items: List<HistoryItem>) {
        p.edit()
            .putString("items", items.joinToString("\n") { "${it.number}|${it.time}|${it.source}" })
            .apply()
    }
}
