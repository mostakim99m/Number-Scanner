package com.numberscanner.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Accent = Color(0xFF00E5FF)
val OnAccent = Color(0xFF00222A)
val Bg = Color(0xFF090E1A)
val Surface1 = Color(0xFF111927)
val Surface2 = Color(0xFF16213E)
val Border = Color(0xFF1F2B4A)
val SubText = Color(0xFF8A94A8)
val Success = Color(0xFF4ADE80)
val ErrorRed = Color(0xFFFF6B6B)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            onPrimary = OnAccent,
            secondary = Accent,
            onSecondary = OnAccent,
            background = Bg,
            onBackground = Color.White,
            surface = Surface1,
            onSurface = Color.White,
            surfaceVariant = Surface2,
            onSurfaceVariant = SubText,
            surfaceContainer = Surface1,
            surfaceContainerLow = Surface1,
            surfaceContainerHigh = Surface2,
            outline = Border,
            error = ErrorRed,
        ),
        content = content,
    )
}
