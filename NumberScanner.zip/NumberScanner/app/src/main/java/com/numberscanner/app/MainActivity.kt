package com.numberscanner.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.numberscanner.app.ui.Accent
import com.numberscanner.app.ui.AppTheme
import com.numberscanner.app.ui.Bg
import com.numberscanner.app.ui.HistoryScreen
import com.numberscanner.app.ui.OnAccent
import com.numberscanner.app.ui.ScannerScreen
import com.numberscanner.app.ui.SettingsScreen
import com.numberscanner.app.ui.SubText

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        val settingsRepo = SettingsRepo(this)
        val historyRepo = HistoryRepo(this)
        setContent {
            AppTheme {
                App(settingsRepo, historyRepo)
            }
        }
    }
}

private enum class Screen { Scanner, Settings, History }

@Composable
private fun App(settingsRepo: SettingsRepo, historyRepo: HistoryRepo) {
    val context = LocalContext.current
    var settings by remember { mutableStateOf(settingsRepo.load()) }
    var screen by remember { mutableStateOf(Screen.Scanner) }

    fun cameraGranted() = ContextCompat.checkSelfPermission(
        context, Manifest.permission.CAMERA
    ) == PackageManager.PERMISSION_GRANTED

    var hasCamera by remember { mutableStateOf(cameraGranted()) }
    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> hasCamera = granted }

    LaunchedEffect(Unit) {
        if (!hasCamera) permLauncher.launch(Manifest.permission.CAMERA)
    }
    // Re-check after returning from the phone's settings
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        hasCamera = cameraGranted()
    }

    val update: (AppSettings) -> Unit = { s ->
        settings = s
        settingsRepo.save(s)
    }

    when (screen) {
        Screen.Scanner ->
            if (hasCamera) {
                ScannerScreen(
                    settings = settings,
                    onSettingsChange = update,
                    historyRepo = historyRepo,
                    onOpenSettings = { screen = Screen.Settings },
                    onOpenHistory = { screen = Screen.History },
                )
            } else {
                PermissionScreen { permLauncher.launch(Manifest.permission.CAMERA) }
            }

        Screen.Settings -> {
            BackHandler { screen = Screen.Scanner }
            SettingsScreen(settings, update, onBack = { screen = Screen.Scanner })
        }

        Screen.History -> {
            BackHandler { screen = Screen.Scanner }
            HistoryScreen(historyRepo, settings, onBack = { screen = Screen.Scanner })
        }
    }
}

@Composable
private fun PermissionScreen(onRequest: () -> Unit) {
    val context = LocalContext.current
    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(Icons.Filled.CameraAlt, null, tint = Accent, modifier = Modifier.size(64.dp))
        Spacer(Modifier.height(20.dp))
        Text("ক্যামেরার অনুমতি দরকার", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "নম্বর স্ক্যান করতে ক্যামেরা লাগবে। কোনো ছবি সেভ বা কোথাও পাঠানো হয় না (AI চালু থাকলে শুধু নম্বরের অংশটুকু AI-তে যায়)।",
            color = SubText,
            fontSize = 14.sp,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(24.dp))
        Button(
            onClick = onRequest,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = OnAccent),
        ) {
            Text("অনুমতি দিন", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        TextButton(onClick = {
            context.startActivity(
                Intent(
                    android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", context.packageName, null),
                )
            )
        }) {
            Text("ফোনের সেটিংস থেকে অনুমতি দিন", color = SubText)
        }
    }
}
