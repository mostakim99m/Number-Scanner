package com.numberscanner.app

/** Finds Bangladeshi mobile numbers (01[3-9]XXXXXXXX) in OCR text. */
object NumberExtractor {

    private val valid = Regex("^01[3-9]\\d{8}$")
    private val with880 = Regex("\\+?880(1[3-9]\\d{8})(?!\\d)")
    private val local11 = Regex("(?<!\\d)(01[3-9]\\d{8})(?!\\d)")
    private val bare10 = Regex("(?<![\\d+])(1[3-9]\\d{8})(?!\\d)")
    private val joinGroups = Regex("(?<=[\\d+])[ \\-.]+(?=\\d)")
    private val spaces = Regex("[ \\t]+")

    fun extract(text: String?): List<String> {
        if (text.isNullOrBlank()) return emptyList()
        val found = LinkedHashSet<String>()

        val base = normalize(text).replace(spaces, " ")
        // Pass 1 keeps side-by-side numbers apart; pass 2 joins "01712-345678", "017 1234 5678"
        val joined = base.replace(joinGroups, "")

        for (t in listOf(base, joined)) {
            with880.findAll(t).forEach { found.add("0" + it.groupValues[1]) }
            local11.findAll(t).forEach { found.add(it.groupValues[1]) }
            bare10.findAll(t).forEach { found.add("0" + it.groupValues[1]) }
        }
        return found.filter { valid.matches(it) }
    }

    /** Bengali digits → ASCII, and common OCR confusions (O→0, l/I/|→1). */
    private fun normalize(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) {
            sb.append(
                when (c) {
                    in '০'..'৯' -> '0' + (c - '০')
                    'o', 'O' -> '0'
                    'l', 'I', '|' -> '1'
                    else -> c
                }
            )
        }
        return sb.toString()
    }

    fun pretty(n: String): String =
        if (n.length == 11) n.substring(0, 5) + "-" + n.substring(5) else n

    fun operatorName(n: String): String = when (n.take(3)) {
        "017", "013" -> "Grameenphone"
        "019", "014" -> "Banglalink"
        "018" -> "Robi"
        "016" -> "Airtel"
        "015" -> "Teletalk"
        else -> ""
    }
}
