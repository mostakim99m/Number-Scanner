package com.numberscanner.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

/** OpenAI-compatible vision API (Groq, OpenAI, OpenRouter, local Ollama, ...). */
object VisionApi {

    class ApiException(message: String) : Exception(message)

    private const val PROMPT = """Extract ALL phone numbers from this image — printed, screen display, or handwritten (including Bengali digits ০-৯).
Return ONLY a JSON array of digit strings. No explanation. No markdown. No extra text.
Example: ["01712345678","01987654321"]
Rules:
- Bangladeshi mobile numbers are 11 digits starting with 013-019
- Digits only — remove spaces, dashes, brackets, +880 prefix becomes 0
- Handwriting: read every digit carefully. Commonly confused: 3/8/9, 1/7, 4/9, 5/6, 0/6. Look at the actual stroke shapes.
- Count the digits: a Bangladeshi number has exactly 11.
- If none found, return []"""

    suspend fun extractNumbers(bitmap: Bitmap, s: AppSettings): List<String> = withContext(Dispatchers.IO) {
        if (!s.hasApiKey) throw ApiException("API key missing")

        val scaled = ImageUtils.scaleDown(bitmap, 1600)
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 90, out)
        val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)

        val content = JSONArray()
            .put(
                JSONObject()
                    .put("type", "image_url")
                    .put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64"))
            )
            .put(JSONObject().put("type", "text").put("text", PROMPT))

        val body = JSONObject()
            .put("model", s.model.ifBlank { DEFAULT_MODEL })
            // Thinking models spend tokens inside <think>; keep this high
            .put("max_tokens", 2048)
            .put("temperature", 0)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))

        val conn = (URL(s.endpoint.ifBlank { DEFAULT_ENDPOINT }).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15_000
            readTimeout = 45_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Bearer ${s.apiKey.trim()}")
        }
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = runCatching {
                    JSONObject(text).getJSONObject("error").getString("message")
                }.getOrNull()
                throw ApiException(msg ?: "API $code")
            }
            val reply = JSONObject(text)
                .getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").optString("content", "")
            parse(reply)
        } finally {
            conn.disconnect()
        }
    }

    private fun parse(reply: String): List<String> {
        var raw = reply
            .replace(Regex("<think>[\\s\\S]*?</think>", RegexOption.IGNORE_CASE), "")
            .replace(Regex("<think>[\\s\\S]*", RegexOption.IGNORE_CASE), "")
            .replace(Regex("```[a-zA-Z]*"), "")
            .trim()
        val match = Regex("\\[[\\s\\S]*?]").find(raw)
        val result = LinkedHashSet<String>()
        if (match != null) {
            raw = match.value
            val arr = runCatching { JSONArray(raw) }.getOrNull()
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    result.addAll(NumberExtractor.extract(arr.optString(i)))
                }
                return result.toList()
            }
        }
        // Fallback: model ignored the format — search the whole reply
        result.addAll(NumberExtractor.extract(raw))
        return result.toList()
    }

    /** Sends a generated image of a known number to check endpoint + key + model. */
    suspend fun test(s: AppSettings): Boolean {
        val bmp = Bitmap.createBitmap(900, 220, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.WHITE)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 96f
            typeface = Typeface.MONOSPACE
        }
        c.drawText("01712-345678", 40f, 145f, paint)
        return extractNumbers(bmp, s).contains("01712345678")
    }

    fun friendlyError(e: Throwable): String {
        val m = e.message ?: ""
        fun has(p: String) = Regex(p, RegexOption.IGNORE_CASE).containsMatchIn(m)
        return when {
            e is SocketTimeoutException || has("timeout|timed out") -> "⏱️ Timeout — ইন্টারনেট চেক করুন"
            e is UnknownHostException -> "📶 ইন্টারনেট সংযোগ নেই"
            has("rate.?limit") -> "⏳ Rate limit — একটু পর আবার চেষ্টা করুন"
            has("401|invalid.*key|api.?key") -> "🔑 API Key সমস্যা — Settings চেক করুন"
            has("model") && has("not|exist|found|support|decommission") -> "🤖 মডেল সমস্যা — Settings-এ মডেল চেক করুন"
            has("overload|busy|capacity|high.?demand|503") -> "🔄 সার্ভার ব্যস্ত — একটু অপেক্ষা করুন"
            else -> "⚠️ " + m.replace(Regex("\\s+"), " ").take(120)
        }
    }
}
